
public class Media 
{
String code; // code unique de chaque m�dia
//int nbE; // nombre d'exmplaires
int nbD; // nombre d'exemplaires disponibles
public Media(String code,int nbD)
{	this.code=code;
	this.nbD=nbD;
}	
public String toString()
{
String s="";
String catg=this.getClass().getName();
/*Autrement
 * String catg="";
 * if this instanceof Ouvrage
 *  catg="Ouvrage";
 *  else 
 *    catg="Dvd";
 */
s=" Le m�dia "+catg+"  a pour code"+this.code+ " le nombre d'exemplaires disponibles "+this.nbD;
return s;
}
}
