import java.util.Scanner;
public class Palindrome 
{String s;
Palindrome(String s)
{this.s=s;}

boolean pal(StringBuffer sb)
{if(sb.length()<=1)
	return true;
if ( sb.charAt(0)!= sb.charAt(sb.length()-1) )
   return false;
  sb.deleteCharAt(0);
  sb.deleteCharAt(sb.length()-1);
return pal(sb) ; 
 }	
	public static void main(String[] args)
	{ Scanner clavier= new Scanner(System.in);
			System.out.println("Entrer une chaine de caract�res : ");
		String ch=clavier.next();
		Palindrome obj= new Palindrome(ch);
		StringBuffer sb= new StringBuffer(obj.s);
		System.out.print(obj.s ); 
		if (obj.pal(sb))
				System.out.println (" est un palindrome ");
		else
			System.out.println (" n 'est pas un palindrome ");	
	clavier.close();
	}

}
