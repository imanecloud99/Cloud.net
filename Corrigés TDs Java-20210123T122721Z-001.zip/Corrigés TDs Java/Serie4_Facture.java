   import java.util.*;
      public class Serie4_Facture
   { Iterator valeurs;
      TreeSet liste_factures;
      
      public int nombre_Factures(int v1,int v2)
      {
         Integer obj1= new Integer(v1);
         Integer obj2= new Integer(v2);
           SortedSet s=liste_factures.subSet(obj1, obj2);
         int n=s.size();
         if (liste_factures.contains(obj2)) n++;
         return n;   
      
      }
      public void ajouterFacture(int m)
      {int num=0;
      if(!(liste_factures.isEmpty()))
    	  num=((Integer)liste_factures.last()).intValue();
        for(int i=num+1;i<=num+m;i++)
            liste_factures.add(new Integer(i));
      }
   
      public void payer_Factures(int v1, int v2)
      {Integer ele;
         int n=nombre_Factures(v1,v2);
         System.out.println("nombre de factures � supprimer "+n);
             if  (n>0)
         {
            Integer obj1= new Integer(v1);
            Integer obj2= new Integer(v2);
             TreeSet s= new TreeSet();
             s.addAll( liste_factures.subSet(obj1, obj2));
              if (liste_factures.contains(obj2))
            	 s.add(obj2);
             
             this.liste_factures.removeAll(s);
             s.clear();
                  
            }
         }   
  
      public void afficher()
      {Object ele;
         valeurs=liste_factures.iterator();
         while(valeurs.hasNext())
         {ele=valeurs.next();
            System.out.println(ele);
         }
      }
      public static void main(String[] args)
      { 
    	  Serie4_Facture  obj = new Serie4_Facture();
         obj.liste_factures = new TreeSet();
         Scanner clavier= new Scanner(System.in);
         int choix,val1,val2;
         do{
            System.out.println(" 1 : ajouter des factures � l'ensemble");
            System.out.println(" 2 : afficher les elements par ordre ");
            System.out.println(" 3 : nombre de  factures dont les num�ros sont compris entre 2 valeurs ");
            System.out.println(" 4 : suppression des  factures payees");
            System.out.println(" 5 : Fin ");
            System.out.println(" Entrer votre choix : ");
            choix=clavier.nextInt();
            switch(choix)
            { 
               case 1 :
                  {
                     System.out.println("Entrer le nombre d'elemnts � ajouter :");
                     int n=clavier.nextInt();
                     obj.ajouterFacture(n);
                     break;
                  }
               
               case 2 : obj.afficher();
                  break;
            
               case 3 :System.out.print("\n Entrer la premiere valeur  � consid�rer :");
                   val1=clavier.nextInt();
                  System.out.print("\n Entrer la deuxieme valeur � consid�rer :");
                   val2=clavier.nextInt();
                    System.out.println("nombre de factures de num�ros comris entre "+val1+ " et "+val2+ "est "+obj.nombre_Factures(val1, val2));
                  break;
               case 4 :System.out.print("\n Entrer la valeur de la premiere facture � supprimer :");
                   val1=clavier.nextInt();
                  System.out.print("\n Entrer la valeur la derni�re facture � supprimer :");
                   val2=clavier.nextInt();
                  obj.payer_Factures(val1, val2);
                   break;
               case 5 :System.out.print("\n Fin du programme");
                  break;   
               default :
                  System.out.println("erreur recommencer");
            } 
         }
         while (choix!=5);
         clavier.close();
      }
   }
