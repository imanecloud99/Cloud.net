public class Utilisateur 
{
	String identite;
	static final int MAX_OUV=3;// le nombre maximum d'ouvrages � emprunter 
	static final int MAX_DVD=2; /// le nombre maximum de DVD  � emprunter  
	Media[] emprunts;// tous les m�dias emprunt�s par l'utilisateur
	Utilisateur (String identite)
	{this.identite=identite;
	this.emprunts= new Media[MAX_OUV+MAX_DVD];
	for(int  i=0;i<MAX_OUV+MAX_DVD;i++)
	  this.emprunts[i]=null;
	}
	int ouv_Emprunts()
	{int nbM=0,nbO=0;
	while((nbM<MAX_OUV+MAX_DVD)&& (this.emprunts[nbM]!=null))
		if(this.emprunts[nbM] instanceof Ouvrage )nbO++;	
	return nbO;
	}
	int dvd_Emprunts()
	{int nbM=0,nbD=0;
	while((nbM<MAX_OUV+MAX_DVD)&& (this.emprunts[nbM]!=null))
		if(this.emprunts[nbM] instanceof Dvd )nbD++;	
	return nbD;
	}
	
	boolean emprunter (Media md)
	{if(md.nbD==0)
			return false;
	int nbE= ouv_Emprunts()+dvd_Emprunts();
	if (md instanceof Ouvrage)
	{ if (ouv_Emprunts()<MAX_OUV)
		emprunts[nbE]=md;
	 return true;
	}
	if (md instanceof Dvd)
	{ if (dvd_Emprunts()<MAX_DVD)
		emprunts[nbE]=md;
	return true;
	}
	return false;
	}
	
	
	boolean rendre (Media md)
	{int i=0;
	int nbE= ouv_Emprunts()+dvd_Emprunts();
	while((i<nbE)&&   (!(emprunts[i].equals(md)) )  )
	 i++;	
		if(i<nbE) // le m�dia a �t� trouv�
	    {// d�calage
			for(int j=i;j<nbE-1;j++)
				emprunts[j]=emprunts[j+1];
			emprunts[nbE-1]=null;
	     md.nbD++;
		return true;
        }
return false;
		
	}
}
