
public class Ouvrage extends Media
{
String auteur;
String titre;

public Ouvrage(String code, int nbD,String auteur, String titre, int edition) {
	super(code, nbD);
	this.auteur=auteur;
	this.titre=titre;
	
	}
}
