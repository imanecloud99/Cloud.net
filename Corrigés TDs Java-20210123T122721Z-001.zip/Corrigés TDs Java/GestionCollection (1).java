import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;

public class GestionCollection 
{
	TreeSet tri_entiers(Vector v)
	{
		TreeSet tset= new TreeSet();
		for(int i=0;i<v.size();i++)
		{
		if(v.elementAt(i) instanceof Integer)
		
		tset.add(v.elementAt(i));
		}
			return tset;
	}

	/***********************************************************/
	void supprimRedondants(Vector v) 
	{
		/*int i,j,k;
	  k=v.size();
	  for( i=0;i<k;i++)
	  {
	 	j=i+1;
	  	 while(j<k)
		 {  if( (v.elementAt(i)).equals(v.elementAt(j)))	
	         { v.remove(j);
	          k--;}
	       else
	        j++;
	      } // fin while
	  }  // fin for   
	}// fin de la m�thode */
	
		Object obj=null;
		int i,j,k;
		i=0;
		k=v.size();
		 for( i=0;i<k;i++)
		 {
			 obj= v.elementAt(i);
			 j=v.lastIndexOf(obj);
			 while (i!=j)
			 { 	v.remove(j);
			 	k--;
			 	j=v.lastIndexOf(obj);
			 }
		}// fin for
	
}
	void affich_merite(Vector eleve, TreeSet moyenne)
	{
		Iterator it;
		Double objD=null;
	int i=eleve.size()-1,classement=1;
	
/*
	for(int k=moyenne.size()-1;k>=0;k--)
	{  it=moyenne.iterator();

		for(int j=0;j<=k;j++)
		{objD=(Double)it.next();}
		System.out.print(classement+" :  ");
		System.out.print(eleve.elementAt(i)+"  ");
		System.out.println(objD+"  ");
		i--;
		classement++;
	}
	 
	 }*/
	  	
	 //Autrement
	
	 it=moyenne.descendingIterator();
	 while(it.hasNext())
	 {objD=(Double)it.next();
		System.out.print(classement+" :  ");
		System.out.print(eleve.elementAt(i)+"  ");
		System.out.println(objD+"  ");
		i--;
		classement++;
	}
	} 
}
