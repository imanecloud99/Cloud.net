public class ResoudreEquation {

		public static void main(String[] args) {
		double a2=Double.parseDouble(args[0]);
		double b2=Double.parseDouble(args[1]);
		double c2=Double.parseDouble(args[2]);
		Equation2 equat2= new Equation2(a2,b2,c2);
		System.out.println(equat2.resoudre2());
		
	}

}
