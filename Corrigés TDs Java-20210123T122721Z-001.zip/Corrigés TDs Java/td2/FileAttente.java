
public class FileAttente 
{
	Object[] tab;
	final int MAX;
	FileAttente (int MAX) 
	{
       this.MAX = MAX;
       tab = new Object [MAX];
        for(int i=0;i<this.MAX;i++)
        	this.tab[i]=null;
    }
	
	int indiceDer() 
	{
		int indice=-1,i=0;
		while((i<MAX)&&(tab[i]!=null))
		 i++;
		if (i!=MAX)
		 indice=i-1;
		return indice;
	}
	boolean enfiler(Object ob) 
	{int indiceQueue=this.indiceDer();
		if(indiceQueue==MAX-1)
 				return false;
	tab[indiceQueue+1]=ob;
	return true;
	}
Object defiler() 
{int indiceQueue=this.indiceDer();
	if(indiceQueue==-1)
	return null;
	Object ob=tab[0];
	for(int i=0;i<indiceQueue;i++)
	{this.tab[i]=this.tab[i+1];}
	tab[indiceQueue]=null;
return ob;
}
public static void main(String[] arg)
{FileAttente fa= new FileAttente(6);
String ob1="aa",ob2="bb",ob3="cc";
fa.tab[0]=ob1;
fa.tab[1]=ob2;
fa.tab[2]=ob3;
int indiceQueue=fa.indiceDer();
System.out.println(" Les �lements de la file d'attente sont: ");
for(int i=0;i<=indiceQueue;i++)
{System.out.println(fa.tab[i]);}
System.out.println(" L'indice du dernier �lement de la file est "+fa.indiceDer());
String nv="nouveau";
fa.enfiler(nv);
indiceQueue=fa.indiceDer();
System.out.println("la file apr�s ajout de l'elemnt nouveau est");
for(int i=0;i<=indiceQueue;i++)
{System.out.println(fa.tab[i]);}
fa.defiler();
indiceQueue=fa.indiceDer();
System.out.println("la file apr�s suppression du 1er element est:");
for(int i=0;i<=indiceQueue;i++)
{System.out.println(fa.tab[i]);}

}


}
