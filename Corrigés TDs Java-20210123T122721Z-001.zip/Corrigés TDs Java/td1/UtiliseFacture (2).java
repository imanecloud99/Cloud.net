import java.util.Scanner;


public class UtiliseFacture {
	 public static void main(String[] args)
     
     {int numer;
        String nm;  
        Scanner clavier= new Scanner(System.in);
        Serie1_Facture fact1,fact2;
        System.out.println(" saisie des informations de la 1ere facture : ");
           System.out.print("Num : ");
           numer=clavier.nextInt();
           System.out.print("Nom : ");
           nm=clavier.next();
           fact1= new Serie1_Facture(numer,nm);
           System.out.println( "Entrer le montant de la 1ere facture : ");
           fact1.montant=clavier.nextDouble();
           System.out.print("Entrer an_limite de la 1�re facture: ");
           fact1.an_limite=clavier.nextInt();
           System.out.println( "Entrer l'�tat de paiement true ou false de la 1 ere facture ");
           fact1.paye=clavier.nextBoolean();
           
           System.out.println(" saisie des informations de la 2eme facture : ");
           System.out.print("Num : ");
           numer=clavier.nextInt();
           System.out.print("Nom : ");
           nm=clavier.next();
           fact2= new Serie1_Facture(numer,nm);        
            System.out.println( "Entrer le montant de la 2�me facture : ");
          fact2.montant=clavier.nextDouble();
          System.out.print("an_limite de la 2�me facture : ");
         fact2.an_limite=clavier.nextInt();
         System.out.println( "Entrer l'�tat de paiement true ou false de la 2�me facture ");
         fact2.paye=clavier.nextBoolean();
       
        System.out.println("les factures sont : ");
        fact1.afficher();
        fact2.afficher();
               
        clavier.close();
        
            }
  
  }


