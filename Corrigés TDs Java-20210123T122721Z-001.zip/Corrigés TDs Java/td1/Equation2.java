 class Equation2 
{
double a2,b2,c2;
Equation2(double a2,double b2,double c2)
{this.a2=a2;
this.b2=b2;
this.c2=c2;
}
String resoudre2()
{String sol="";
	
	if(a2==0){
		Equation1 equ1= new Equation1(b2,c2);
		sol=equ1.resoudre1();
	}
	else
	{ double delta=(b2*b2)-4*a2*c2;
		if(delta<0)
			sol="Pas de solution dans R";
		else if(delta==0)
		{double x=(-b2/(2*a2));
		sol="La solution est "+x;
		}
		else
		{
		double x1=(-b2-Math.sqrt(delta))/(2*a2);
		double x2=(-b2+Math.sqrt(delta))/(2*a2);
		sol=" Les solutions sont "+x1+" et "+x2;
	}
		
}
	return sol;
}
}
  