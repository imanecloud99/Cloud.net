 class Equation1 {
	double a1,b1;
	Equation1(double a1,double b1)
	{this.a1=a1;
	this.b1=b1;}
	
	
	String resoudre1()
	{String sol="";
		if(a1==0)
		{if(b1==0)
			sol="Tout R";
		else
				sol="Ensemble vide";}
		else
		{double x=-b1/a1;
		sol="La solution est "+x;	
		}
		
	return sol;	
		
		
	}
}