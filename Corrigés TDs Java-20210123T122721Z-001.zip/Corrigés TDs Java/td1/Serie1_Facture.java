 public class Serie1_Facture {
           
      int num;
      String nom;
      double montant;
      int an_limite;
      boolean paye;
      static int an_courant=2020;
              
      Serie1_Facture(int num,String nom)   
              
      {this.num=num;
         this.nom=nom;
      }
              
      boolean depassee() 
      {
         if((!paye) && (an_limite<an_courant))
            return true;
         return false;}
              
      double penalite()
       {double p=0;
       double m=montant;
         if(depassee()) 
            for(int i=an_limite;i<an_courant;i++)
            {           
               p=p+(m*0.1);
               
              m=m+p;
            }
         montant=montant+p;
      
         return p;
      }
              
      void afficher()
              
      {  System.out.println(" /************ Facture ******************/");
    	  System.out.println("Facture Num�ro : "+num);
         System.out.println("Nom : "+nom);
         System.out.println("Pay� : "+paye);
         System.out.println("Montant : "+montant);
         System.out.println("An_limite : "+an_limite);
         System.out.println("P�nalit� : "+penalite());
         System.out.println("Montant apr�s mise � jour : "+montant);
      }
   
   }            
     