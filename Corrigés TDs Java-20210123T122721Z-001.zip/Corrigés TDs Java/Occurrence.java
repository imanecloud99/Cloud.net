
import java.util.Scanner;
public class Occurrence {
String chaine;
 Occurrence(String chaine)
 {this.chaine=chaine;}
	public void occ()
	{int i,j,occur;
	 char c1,c2;
	 int l=chaine.length();
		for( i=0;i<l;i++)
		{  c1=(chaine.toLowerCase()).charAt(i); 
			occur=1;
			j=-1;
			do
			{
				j++;
				c2=(chaine.toLowerCase()).charAt(j); 
			}while( (j<i) &&( c1!=c2) );
		  if(j==i)
		  {for( j=i+1;j<l;j++)
		  {c2=(chaine.toLowerCase()).charAt(j);
			if(c1==c2)
				occur++;
		  }
		 System.out.println(" le nombre d'occurrences de "+c1+" ="+occur);
		}	
		}
		
	}
	public static void main(String[] args)
	{Scanner clavier= new Scanner(System.in);
	System.out.println("Entrer la chaine ");
	String s=clavier.next();
		Occurrence  obj= new Occurrence(s);
		obj.occ();
		clavier.close();
	}

}
