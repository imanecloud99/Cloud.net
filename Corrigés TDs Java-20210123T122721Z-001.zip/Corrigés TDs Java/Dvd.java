
public class Dvd extends Media{
	String intitule;
	public Dvd(String code, int nbD, String intitule) 
	{
		super(code, nbD);
		this.intitule=intitule;
		}
}
